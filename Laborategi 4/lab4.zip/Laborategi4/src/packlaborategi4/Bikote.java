package packlaborategi4;

public class Bikote {
	String aktoreaEdoPelikula;
	
	Double pageRank;
	
	public Bikote(String izena, Double rank) {
		this.aktoreaEdoPelikula=izena;
		this.pageRank=rank;
	}
}
