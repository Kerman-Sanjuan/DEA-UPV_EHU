package packlaborategi4;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Scanner;

public class GraphHash {
	HashMap<String, ArrayList<String>> grafo;
	HashMap<String, Double> pageRank;
	
	
	public GraphHash() {
		this.grafo= new HashMap<String, ArrayList<String>>();
	}
	public void grafoaSortu(listaAktore lAktoreak) {
			Iterator<String> itr = lAktoreak.getIteradorea();	
			while(itr.hasNext()) {
				String aktorea = itr.next();
				Aktore unekoa = lAktoreak.bilatuAktorea(aktorea);
				ArrayList<String> listaP = new ArrayList<String>();
			//	listaP.clear(); por si las moscas
				Iterator<Pelikula> iteratorPeli = unekoa.getPelikulak().iterator();
				while(iteratorPeli.hasNext()) {
					String unekoP = iteratorPeli.next().getIzena();
					listaP.add(unekoP);
					ArrayList<String> pelikularenAkt;
					if(this.grafo.containsKey(unekoP)) {
						pelikularenAkt=this.grafo.get(unekoP);
					}else {
						pelikularenAkt=new ArrayList<String>();
					}
					pelikularenAkt.add(aktorea);
					grafo.put(unekoP, pelikularenAkt);
				}
				//una vez hemos gestionado todas su pelikulas, a�adimos el actor + listaP (sus pelis)
				grafo.put(aktorea, listaP);
				
			}
//			System.out.println(grafo.size()+ " Elementu ditu grafoak.");	
		}
	
	
	
	public int luzeera() {
		return this.grafo.size();
	}

	
	
	public void clear() {
		this.grafo.clear();
	}
	public boolean konektatuta(String a1, String a2) { //Metodo principal, saber si dos elementos estan conectados
		HashSet<String> aztertuak = new HashSet<String>();
		Queue<String> aztGabeak = new LinkedList<>();
		aztGabeak.add(a1);
		if(a1.equals(a2)) {
			return true; //Caso tonto, pero bueno, por si acaso
		}
		if(grafo.isEmpty()|| !grafo.containsKey(a1)) { //YO AQUI PONDRIA || !grafo.containsKey(a1)
			return false;
		}
		while(!aztGabeak.isEmpty()) {//Falta la otra condicion de salida.
			if(!aztertuak.contains((String)aztGabeak.peek())) {
				if(aztGabeak.peek().equals(a2)) {
					return true;
				}else {
					String uneko = aztGabeak.peek();
					aztertuak.add(uneko);
					aztGabeak.poll(); //Me cargo el primer elemento.
					ArrayList<String> lista = grafo.get(uneko);
					Iterator<String> itr = lista.iterator();
					while(itr.hasNext()) {
						String tmp = itr.next();
						aztGabeak.add(tmp);
					}

				}
			}else { //Es decir, que el elemento ya ha sido investigado
				aztGabeak.poll(); //Me cargo el elemento ya investigado.
			}
		}
		return false;
	}

		

	
	public void print() {
		/*Iterator<String> itr = grafo.keySet().iterator();
		while(itr.hasNext()) {
			String uneko = itr.next();
			System.out.println("El nodo " + uneko + " esta relacionado con:");
			ArrayList<String> lista = grafo.get(uneko);
			for (int i=0;i<lista.size();i++) {
				System.out.println(lista.get(i));
			}
		}*/
		int i = 1;
		for (String s: grafo.keySet()){
		System.out.print("Element: " + i++ + " " + s + " --> ");
		for (String k: grafo.get(s)){
		System.out.print(k + " ### ");
		}
		System.out.println();
		}
	}
	
	public void probaEnpirikoak() {
		Object[] values = grafo.keySet().toArray();
		long denbora = 0;
		int n = 100;
		int t = 0;
		int f = 0;
//		System.out.println("Estoy fuera del for");
		for(int i = 1;i<=n;i++) {
			
//			System.out.println("Estoy en la iteracion "+ i);
			double r1=(Math.random() * ((values.length-1)));
			double r2=(Math.random() * ((values.length-1)));
			int z1= (int) Math.round(r1);
			int z2= (int) Math.round(r2);
//			System.out.println(z1 + " eta "+ z2 + " balioak sortu ditut");
			String randomValue1 = values[z1].toString();
			String randomValue2 = values[z2].toString();
//			System.out.println(randomValue1);
//			System.out.println(randomValue2);
			long startTime = System.currentTimeMillis();
//			System.out.println(this.konektatuta(randomValue1, randomValue2));
			if(this.konektatuta(randomValue1, randomValue2)) {
				t++;
			}else {
				f++;
			}
			long endTime = System.currentTimeMillis();
			denbora = denbora + (endTime-startTime);
			if(i% 10 == 0) {System.out.println(i+" proba egin ditut");
			
			}
		
		
		}
	System.out.println(t+ " True kasu egon dira");
	System.out.println(f+ " False kasu egon dira");
	System.out.println((denbora/n)+" Milisegundo behar ditu batazbeste konexioa egiaztatzeko");
	}
	//--------------------------------------------------------- Page Rank metodoa-----------------------------------------------------
	
	public HashMap<String, Double> PageRank() {
		System.out.println("Page Rank-a hasieratzen.");
		int bucles = 0;
		HashMap<String, Double> unekoa= this.pageRankHasieratu();
		System.out.println("Page Rank hasieratu egin da.");
		HashMap<String, Double> hurrengoa;
		double error=1000; 							//1000 por poner un numero mayor que 0.00001
		double p = 0.85;							//la probabilidad que koldo dijo
		long startTime = System.currentTimeMillis();
		System.out.println("Page Rank-aren kalkuloa hasi egingo da.");
		while(error>0.0001) { 						//mientras las puntuaciones cambien mas de 0.00001 entre un ciclo y otro, seguimos
			Iterator<String> itrGrafo = grafo.keySet().iterator(); //cojemos cada elemento
			hurrengoa =new HashMap<String, Double>();
			while(itrGrafo.hasNext()) {  			//con este bucle repartimos la importancia de cada elemento entre sus relaciones, aun falta hacer eso *p + 1-p/N
				String unekoStr = itrGrafo.next();
				Double unekoP = unekoa.get(unekoStr);
				ArrayList<String> erlazioak = grafo.get(unekoStr);
				Iterator<String> itrErl= erlazioak.iterator(); //El iterador de las relaciones.
				while(itrErl.hasNext()) {
					String unekoErl = itrErl.next();
					if(hurrengoa.containsKey(unekoErl)) {	 //si el elemento ya esta en el grafo, lo sacamos, a�adimos lo que toca y lo volvemos a poner
						Double punt = hurrengoa.get(unekoErl);
						hurrengoa.remove(unekoErl);
						punt=punt+unekoP/erlazioak.size();
						hurrengoa.put(unekoErl, punt);
					}else { 								// si no estaba, lo a�adimos
						Double punt = unekoP/erlazioak.size();
						hurrengoa.put(unekoErl, punt);
					}	
				}
			}
			Iterator<String> itrFormula = grafo.keySet().iterator();
			double dif = 0;
			while(itrFormula.hasNext()) {
				String unekoa2= itrFormula.next();
				dif = dif + Math.abs(unekoa.get(unekoa2)-hurrengoa.get(unekoa2));
				Double punt = hurrengoa.get(unekoa2);
				hurrengoa.put(unekoa2, (punt*p) + ((1-p)/hurrengoa.size())); 			//aqui ya hemos hecho la punt*p + 1-p/N
			}/* He comentado esto de abajo.
			Iterator<String> itrError = grafo.keySet().iterator();
			double dif = 0;
			while(itrError.hasNext()) {													//calculamos el error 
				String unekoaa = itrError.next();
				dif = dif + Math.abs(unekoa.get(unekoaa)-hurrengoa.get(unekoaa)); 		//Error=Suma de (puntuacion anterior - nueva) para cada elemento
			}*/
			error=dif;
//			System.out.println("El error en el ultimo bucle ha sido de " + error);
			unekoa=hurrengoa; 	//actualizamos el grafo unekoa
													//			if(bucles==0) {  												//esto solo esta para ver si los calculos que hice yo de la primera iteracion estan bien
													//				Iterator<String> itr = unekoa.keySet().iterator(); 
													//				while(itr.hasNext()) {
//					String a = itr.next();
//					System.out.println("El nodo " + a + " tiene una puntuacion de: "+unekoa.get(a));
//				}
//			}
			bucles++;
			//<----- mera curiosidad para saber cuantos bucles hace, unos 70 normalmente
		}
		long endTime = System.currentTimeMillis();
		Iterator<String> itrComrpobracion = unekoa.keySet().iterator();
		double total =0;
		System.out.println("PageRank kalkulatzeko behar izan den denbora: " + (endTime-startTime)/60000 + " minutu eta "+ bucles+" behar izan dira." );
		while(itrComrpobracion.hasNext()) { 					//esto solo esta para comprobar que la suma de todas las puntuaciones es mayor que 1 
			String elem = itrComrpobracion.next();				//puede ser un poco mayor debido a que los doubles van como quieren
//			System.out.println("El elemento "+socorrooooo + " tiene una puntuacion de "+ unekoa.get(socorrooooo));
			total= total+ unekoa.get(elem);						//se puede quitar toda esta comprobacion y lo relacionado a ella
		}
		System.out.println("Puntuazioa batekoa izan beharko litzateke eta gure puntuazioa " + total +  " da.");
//		System.out.println("Elementos en unekoa: " + k);

		
		this.pageRank=unekoa;
		
		return this.pageRank;
	}
	
	public ArrayList<Bikote> bilatu(String pHelbide) {
		HashMap<String, Double> lag= new HashMap<String, Double>();
		Iterator<String> itrHitzaDute = this.pageRank.keySet().iterator();
		while(itrHitzaDute.hasNext()) {
			String unekoa = itrHitzaDute.next();
			if(unekoa.toLowerCase().contains(pHelbide.toLowerCase())) { //unekoa elementua bilatzen dugun STRING-a badu, grafo berrian sartzen dugu
//				System.out.println(unekoa);
				lag.put(unekoa, this.pageRank.get(unekoa)); 
			}
		}
		lag=this.sortByValue(lag); //Puntuazio altuenetik txikienera ordenatzen ditugu elementuak
		Iterator<String> itr = lag.keySet().iterator(); //el iterador de los elementos que coinciden
		ArrayList<Bikote> emaitza =new ArrayList<Bikote>();
		HashMap<String, Double> erlazioak = new HashMap<String, Double>();
		if(!itr.hasNext()) {
			System.out.println("Bilatu nahi den elementua ez da agertzen grafoan");
		}else {
			String bilaketa = itr.next(); //pillamos el primero, que sera el que tenga la puntuacion mas alta
//			System.out.println(bilaketa + " bilatu egingo da");
			if(listaAktore.getLista().aktoreaDago(bilaketa)) {
				System.out.println(bilaketa + "-en pelikulak lortuko dira");
				Iterator<Pelikula> itrPelikulak = listaAktore.getLista().bilatuAktorea(bilaketa).getPelikulak().iterator();
				while(itrPelikulak.hasNext()) {
					String unekoP = itrPelikulak.next().getIzena();
					erlazioak.put(unekoP, this.pageRank.get(unekoP));
				}
			}else {
				System.out.println(bilaketa + "-en aktoreak lortuko dira");
				Iterator<Aktore> itrAktoreak = listaPelikula.getLista().itZuliPelikula(bilaketa).getListaAktore().iterator();
				while(itrAktoreak.hasNext()) {
					String unekoA = itrAktoreak.next().getIzena();
					erlazioak.put(unekoA, this.pageRank.get(unekoA));
				}
			}
		}
		erlazioak= this.sortByValue(erlazioak);
		Iterator<String> itrEmaitzak = erlazioak.keySet().iterator();
		while(itrEmaitzak.hasNext()) {   //este codigo esta por si quieres ver todos los resultados de la palabra buscada
			System.out.println(".......");
			String unekoEmaitza = itrEmaitzak.next();
			System.out.println(unekoEmaitza  + ", honako puntuazioarekin: " + this.pageRank.get(unekoEmaitza));
			emaitza.add(new Bikote(unekoEmaitza, this.pageRank.get(unekoEmaitza)));
			;
		}
		return emaitza;
	}
	
	
	 public HashMap<String, Double> sortByValue(HashMap<String, Double> hm)  { 
	        List<Map.Entry<String, Double> > list = new LinkedList<Map.Entry<String, Double> >(hm.entrySet()); 
	        Collections.sort(list, new Comparator<Map.Entry<String, Double> >() { 
	            public int compare(Map.Entry<String, Double> o2,  Map.Entry<String, Double> o1)  { 
	                return (o1.getValue()).compareTo(o2.getValue()); 
	            } 
	        }); 
	          
	        // put data from sorted list to hashmap  
	        HashMap<String, Double> temp = new LinkedHashMap<String, Double>(); 
	        for (Map.Entry<String, Double> aa : list) { 
	            temp.put(aa.getKey(), aa.getValue()); 
	        } 
	        return temp; 
	    } 
	
	public HashMap<String, Double> pageRankHasieratu() {
		Iterator<String> itr = grafo.keySet().iterator();
		HashMap<String, Double> mapa = new HashMap<String, Double>();
		while(itr.hasNext()) {
			double p = 1/(double) grafo.size();
			mapa.put(itr.next(), p); //elementu bakoitzari 1/N puntuazioa ematen diogu
		}	
		return mapa;
	}

}