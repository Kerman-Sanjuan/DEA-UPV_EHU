package packlaborategi4;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;


public class listaAktore {
	private static listaAktore i;
	private HashMap<String,Aktore> lista = null;
	
	public static synchronized listaAktore getLista() {
		if (listaAktore.i == null) {
			listaAktore.i = new listaAktore();
		}
		return i;
	}
// Eraikitzaile pribatua
	private listaAktore() {
		lista = new HashMap<String,Aktore>();
	}

	public void gehituAktorea(Aktore pAktore) {
			this.lista.put(pAktore.getIzena(), pAktore);
	}
	
	public Iterator<String> getIteradorea() {
		Iterator<String> itr =  lista.keySet().iterator();
		return itr;
	}

	public int listaLuzeera() {
		return this.lista.size();
	}
	public void clear() {
		this.lista.clear();
	}
	public Aktore bilatuAktorea(String pIzena) {
		return this.lista.get(pIzena);
	}
	public boolean aktoreaDago(String pIzena) {
		return lista.containsKey(pIzena);
	}

	public void ezabatuAktorea(Aktore pAktore) {
		this.lista.remove(pAktore.getIzena());
	}
	
	
	public ArrayList<String> aktoreOrdenatuak() {
		ArrayList<String> listaordenatua = new ArrayList<>(lista.keySet());
		return mergeSort(listaordenatua);
	}
	public void print() {
		Iterator<String> itr = this.getIteradorea();
		while(itr.hasNext()) {
			String unekoa = itr.next();
			System.out.println(unekoa);
			listaAktore.getLista().bilatuAktorea(unekoa).ikusiPelikulak();
			System.out.println("");
		}
 	}
	public ArrayList<String> mergeSort(ArrayList<String> osoa) {
	    ArrayList<String> ezk = new ArrayList<String>();
	    ArrayList<String> esku = new ArrayList<String>();
	    int erdia;
	 
	    if (osoa.size() == 1) {    //Hau da, listak elementu bakarra badu. 
	        return osoa;
	    } else { //Bestela listan bitan zatituko dugu.
	        erdia = osoa.size()/2;
	        for (int i=0; i<erdia; i++) {
	                ezk.add(osoa.get(i));
	        }
	 
	        for (int i=erdia; i<osoa.size(); i++) {
	                esku.add(osoa.get(i));
	        }
	 
	        //Alde bakoitzari merge-sort algoritmoa aplikatu modu errekurtsiboan.
	        ezk  = mergeSort(ezk);
	        esku = mergeSort(esku);
	 
	        // Batu emaitzak.
	        merge(ezk, esku, osoa);
	    }
	    return osoa;
	}
	
	private void merge(ArrayList<String> ezk, ArrayList<String> esku, ArrayList<String> osoa) {
	    int ezkIndex = 0;
	    int eskuIndex = 0;
	    int osoaIndex = 0;
	 	    //ezk edo esku luzeera duten bitartean, beti zatika joango gara hartzen eta biak bat egiten.
	    while (ezkIndex < ezk.size() && eskuIndex < esku.size()) {
	        if ( (ezk.get(ezkIndex).compareTo(esku.get(eskuIndex))) < 0) {
	            osoa.set(osoaIndex, ezk.get(ezkIndex));
	            ezkIndex++;
	        } else {
	            osoa.set(osoaIndex, esku.get(eskuIndex));
	            eskuIndex++;
	        }
	        osoaIndex++;
	    }
	    ArrayList<String> gelditzenDena;
	    int gelditzenDenaIndex;
	    if (ezkIndex >= ezk.size()) {
	        // Ezkerrko aldia guztiz erabili da.
	        gelditzenDena = esku;
	        gelditzenDenaIndex = eskuIndex;
	    } else {
	        //Eskuineko aldea guztiz erabili da.
	        gelditzenDena = ezk;
	        gelditzenDenaIndex = ezkIndex;
	    }
	    // Kopiatu oraindik amaitu ez den aldea osorik.
	    for (int i=gelditzenDenaIndex; i<gelditzenDena.size(); i++) {
	        osoa.set(osoaIndex, gelditzenDena.get(i));
	        osoaIndex++;
	    }
	}
	
	
}
