package packlaborategi4;
import java.io.File;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import java.util.*;



public class Scannera {

public static void main(String[] args) throws Exception {
	Boolean kargatuta=false;
	listaAktore.getLista().clear();
	System.out.println("Pelikula eta aktoreak kargatzen daude, prozesu honek ez luke denbora luzerik hartu behar");
	while (!kargatuta) {
		kargatuta=listakKargatu();
	}
	new Scannera();
}
//-------------------------------------------------------- ELEGIR LAS OPCIONES---------------------------------------
	public Scannera() throws Exception {
		
		System.out.println("Zer egin nahiko zenuke?");
		System.out.println("1. aukera: Aktore baten pelikula guztiak lortu");
		System.out.println("2. aukera: Aktoreen lista ordenatua lortu");
		System.out.println("3. aukera: Aktore berri bat gehitu");
		System.out.println("4. aukera: Pelikula baten aktoreak lortu");
		System.out.println("5. aukera: Pelikula bati dirua gehitu.");
		System.out.println("6. aukera: Aktore bat ezabatu");
		System.out.println("7. aukera: Fitxategi bat sortu aktoreen zerrenda ordenatuarekin");
		System.out.println("8. aukera: Bi elementuen arteko bidea");
		System.out.println("9. aukera: Bi elementuren arteko konexioaren proba enpirikoak");
		System.out.println("10. aukera: PageRank algoritmoaren bidez bilaketak egin");
		int num = this.idatziInt();
		switch (num) 
		{
	
		case 1: //FUNCIONA. COMPROBADOS CASOS POSIBLES.
			//Comprobado que pasa si mete nombre erroneo.
		    this.aktorearenPelikulak();
		    amaitu();
		    break; //para que despues de preguntar amaitu acabe
	    case 2: // FUNCIONA
		    this.listaOrdenatua();
		    amaitu();
		    break; //para que despues de preguntar amaitu acabe
	  
	    case 3: //FUNCIONA. COMPROBADOS CASOS POSIBLES
		    this.aktoreaGehitu();
		    amaitu(); 
		    break; //para que despues de preguntar amaitu acabe
		    
	    case 4: //Comprobado que ocurre si el nombre es erroneo.
			this.pelikularenAktoreak();
			amaitu(); 
		  	break;
		
		    case 5:
		    this.diruaGehitu();
		    amaitu(); 
		    break;
		    
		    case 6:
		   	this.aktoreaEzabatu();
		   	amaitu(); 
		    break;
		    
		    case 7:
		   	this.aktoreenFitxategiaSortu();
		   	amaitu(); 
		    break;
		    
		    case 8:
		   	this.konektatuta();
		   	amaitu(); 
		    break;
		    
		    case 9:
		    this.denbora();
		    amaitu();
		    break;
		    
		    case 10:
		    this.pageRank();
		    amaitu();
		    break;
		    default:
		    System.err.println ( "Errorea gertatu da sisteman" );
		    this.amaitu();
		    break;
		}

	}
	private void pageRank() {
		GraphHash grafo= new GraphHash();
		grafo.grafoaSortu(listaAktore.getLista());
		grafo.PageRank();
		boolean segi = true;
		while(segi) {
		    System.out.println("Idatzi bilatu nahi duzun elementua "); 
			String ad = this.idatziString();
			grafo.bilatu(ad);
			System.out.println("");
			System.out.println("Beste elementu bat bilatu nahi baduzu sartu 0, bestela edozein zenbaki");
			Scanner bilatu = new Scanner(System.in);
			segi= bilatu.nextInt()==0;
			
		}	
	}
	
	private void denbora() {
		GraphHash grafo= new GraphHash();
		grafo.grafoaSortu(listaAktore.getLista());
		System.out.println("Grafoa modu zuzenean sortu da");
		grafo.probaEnpirikoak();
		
	}
	public void amaitu() throws Exception { //Metodo para cerrar lo que hay que hacer.
		
		System.out.println("Saioa amaitu nahi duzu?");
		System.out.println("BAI sartu 9");
		System.out.println("EZ sartu 0");
		Scanner irten = new Scanner(System.in);
		try {
	       
		switch (irten.nextInt()) 
		{
		    case 9:
		    System.out.println ("Saio amaituko da.");
		    break;
	  
		    case 0:
		    new Scannera();
		    irten.close();
		    break;
		    
		    default:
		    System.err.println ( "Ez dago horrelako aukerarik" );
		    irten.close();
		    break;
		}		
		irten.close();
		}catch (InputMismatchException e) {
			System.err.println("Ez duzu zenbakirik sartu, berriro egin");
			this.amaitu();
		}
	}
//------------------------------------------------------------------- ESCANER----------------------------------------------------------------
	
	public static Boolean listakKargatu() throws Exception{
	  
		long startTime = System.nanoTime();
		String unekoAktore=null;
		String[] linea = null;
	    File file = new File("C:\\Users\\elker\\Desktop\\FilmsActors20162017.txt"); 
	    Scanner sc = new Scanner(file); 
	    TimeUnit.SECONDS.sleep(1);
	    while (sc.hasNextLine()) {
		    linea = sc.nextLine().replace(" &&& ", "<").replace("> ", ">").split("[<>]+"); //la primera linea
		    String pelikulaIzena=linea[0].replace("-","");
		    Pelikula Pelikula1 =new Pelikula(pelikulaIzena,0);
	    	for(int i=1;i<linea.length;i++) { //pongo i=1 porque el primer dato del array es el nombre de la peli y no un actor
	    			unekoAktore=linea[i].replace(", ", " ");
	    			String izena = unekoAktore;
	    			Aktore Aktore1 = new Aktore(izena);//eeeeeeeeeee
	    			if(listaAktore.getLista().aktoreaDago(izena)){
	    				Pelikula1.gehituAktore(listaAktore.getLista().bilatuAktorea(izena));
	    				listaAktore.getLista().bilatuAktorea(izena).gehituPelikula(Pelikula1);
	    			}else {
		    			Pelikula1.gehituAktore(Aktore1);
		    			Aktore1.gehituPelikula(Pelikula1);
		    			listaAktore.getLista().gehituAktorea(Aktore1);	    
	    			}			
	    		}
	    	listaPelikula.getLista().gehituPelikula(Pelikula1);
	    }
	    System.out.println(listaAktore.getLista().listaLuzeera() + " aktore ezberdin daude.");
	    System.out.println(listaPelikula.getLista().listaLuzeera() + " pelikula daude.");
	    long endTime = System.nanoTime();

		long timeElapsed = endTime - startTime;

		System.out.println(timeElapsed / 1000000000 + " segundu behar izan dira. " );
		sc.close();
		return true;
	  }
	
	//-------------------------------------------------------- METODOS DE LAS ACCIONES---------------------------------------------
	public String idatziString() {
		 Scanner s = new Scanner(System.in);
		 String gureString =null;
		 gureString=s.nextLine();
		 return gureString;
	}
	public int idatziInt() throws Exception{
		 Scanner s = new Scanner(System.in);
		 int gureInt = 1;
		try {
			 gureInt=s.nextInt();
		}catch( InputMismatchException e) {
			System.err.println("Ez duzu zenbakirik sartu.");
			return 10;
		}
		return gureInt;
	}
	public ArrayList<Aktore> pelikularenAktoreak()throws Exception{
	    System.out.println("Idatzi pelikularen izena "); 
		String ad = this.idatziString();
//		System.out.println(listaPelikula.getLista().itZuliPelikula(ad) instanceof Pelikula);
		try {
		ArrayList<Aktore> aktoreak = listaPelikula.getLista().itZuliPelikula(ad).getListaAktore();
		System.out.println(aktoreak.size() + " aktore ditu pelikula honek, izenen lista modu egokian lortu da.");
		return aktoreak;
		}  catch (NullPointerException e) {
		System.err.println("Pelikularen izena ez da existitzen.");
		return null;
		}
	}
	public ArrayList<Pelikula> aktorearenPelikulak() throws Exception{

			try {
				System.out.println("Idatzi aktorearen izena");
				String izen= this.idatziString();
				ArrayList<Pelikula> lista = listaAktore.getLista().bilatuAktorea(izen).getPelikulak(); //Esto lo hago para que pueda decir que se ha hecho bien.
				System.out.println("Listak modu egokian itzuli dira.");
				return lista;
				} catch (NullPointerException e) { //Badakit ez dela gomendagarria pointer Exception-a modu honetan tratatzea, baina noizbait erabiltzeko....
				System.err.println("Izena ez da existitzen.");
				return null;
				
			}
		}
				
	
	public ArrayList<String> listaOrdenatua(){
		ArrayList<String> lista =listaAktore.getLista().aktoreOrdenatuak();
		System.out.println("Modu efektiboan lortu da lista ordenatua.");
		return lista;
		
	}
	public void aktoreaGehitu() {
			System.out.println("Idatzi aktorearen izena");
			String izen= this.idatziString();
		   if( listaAktore.getLista().bilatuAktorea(izen) == null) {
			   listaAktore.getLista().gehituAktorea(new Aktore(izen));
			   if(listaAktore.getLista().aktoreaDago(izen)) { //Esto es si lo ha a�adido bien.
				   System.out.println("Aktorea modu egokian gehitu da.");	
			   }
			   }else {
			   System.err.println("Aktorea jadanik dago listan, orduan ez da gehitu.");
		   }
		
	}
	public void diruaGehitu() throws Exception{ //Caso de no mal metido el dinero, o la pelicula no existir, TRATADO:
			System.out.println("Idatzi pelikularen izena"); 
			String iZ=this.idatziString();
			if(listaPelikula.getLista().badagoPelikula(new Pelikula(iZ, 0))) {
		     System.out.println("Idatzi zenbat diru gehitu nahi duzun"); 
			try {
			int dI=Integer.valueOf(this.idatziString());
			listaPelikula.getLista().itZuliPelikula(iZ).diruaGehitu(dI);
			System.out.println("Dirua modu egokian gehitu da, eguneko dirua " +	listaPelikula.getLista().itZuliPelikula(iZ).getDirua()+" eurokoa da." );
			}catch(NumberFormatException e) {
				System.err.println("Ez duzu dirua ondo sartu, berro egin");
				this.diruaGehitu();
			}
			}else {
				System.err.println("Ez dago pelikula, berriro egin"); 
				this.diruaGehitu();
			}
	}
	public void aktoreaEzabatu() {
		System.out.println("Idatzi aktorearen izena:");
		String izen = this.idatziString();
		if(listaAktore.getLista().aktoreaDago(izen)) {
			listaAktore.getLista().ezabatuAktorea(new Aktore(izen));
			System.out.println("Aktorea modu egokian ezabatu da." + '\n');
	
			
		}else {
			System.err.println("Aktorea ez dago, berriro idatzi datuak");
		}
	}
	public void aktoreenFitxategiaSortu() {
		ArrayList<String> lista=listaAktore.getLista().aktoreOrdenatuak();
		File fitxategia;
		try {
			System.out.println();
			System.out.println("Idatzi sortuko den fitxategiaren izena:");
			String fitxIzena=this.idatziString();
			boolean sortuta=false;
			System.out.println("Idatzi sortuko den fitxategiaren helbidea:");
			String fitxHelbidea=this.idatziString();
			fitxategia=new File(fitxHelbidea+"\\"+fitxIzena+".txt"); //Intenta crear el archivo
			while (!sortuta) {
				sortuta=true;
				if (!fitxategia.createNewFile()) { //Comprueba si hay algun fitxategi con el mismo nombre en el mismo helbide
					sortuta=false;
					System.out.println("Jada existitzen da fitxategi bat izen horrekin helbide honetan");
					System.out.println();
					System.out.println("Idatzi sortuko den fitxategiaren izena:");
					fitxIzena=this.idatziString();
					System.out.println("Idatzi sortuko den fitxategiaren helbidea:");
					fitxHelbidea=this.idatziString();
					fitxategia=new File(fitxHelbidea+"\\"+fitxIzena+".txt");
				}
			}
			if (!fitxategia.isFile()) { //Comprueba si se ha creado el fitxategi
				throw new Exception();
			}
			BufferedWriter bw=new BufferedWriter(new FileWriter(fitxategia)); //El aldagai que escribe en el txt
			Iterator<String> itr=lista.iterator();
			String aktorea;
			while (itr.hasNext()) { //Escribe los actores en el txt
				aktorea=itr.next();
				if (itr.hasNext()) {
					bw.write(aktorea+", ");
				}
				else {
					bw.write(aktorea+".");
				}
			}
			bw.close();
			System.out.println("Fitxategia sortu da");
		}
		catch (Exception e) {
			System.err.println("Ezin izan da fitxategia sortu ");
		}
	}
	
	
	public void konektatuta() {
		boolean dago1= false;
		String a1=null;
		String a2=null;
		GraphHash nodoak = new GraphHash();
		nodoak.grafoaSortu(listaAktore.getLista());
		while(!dago1) {
			System.out.println("Idatzi lehenengo elementuaren izena:");
			a1 = this.idatziString();
			if(!listaAktore.getLista().aktoreaDago(a1)) {
				a1=a1+" ";
			}
			dago1=nodoak.grafo.containsKey(a1);
			if(!dago1) {
				System.out.println("Sartu duzun aktorea ez dago aktore listan");
			}
		}

		boolean dago2=false;
		while(!dago2) {
			System.out.println("Idatzi bigarren elementuaren izena:");
			a2 = this.idatziString();
			if(!listaAktore.getLista().aktoreaDago(a2)) {
				a2=a2+" ";
			}
			dago2=nodoak.grafo.containsKey(a2);
			if(!dago2) {
				System.out.println("Sartu duzun aktorea ez dago aktore listan");
			}
		}
		long startTime = System.nanoTime();
		boolean emaitza;
		emaitza= nodoak.konektatuta(a1, a2);
		long endTime = System.nanoTime();
		long timeElapsed = endTime - startTime;
		if(!emaitza) {
			System.out.println("Ez dago biderik " +a1 + " eta " + a2+"-ren artean");
		}else {
			System.out.println("Bide bat dago " + a1+ " eta "+ a2+"-ren artean");
		}
		System.out.println(timeElapsed / 1000000000 + " segundu behar izan dira. " );
	}
}
